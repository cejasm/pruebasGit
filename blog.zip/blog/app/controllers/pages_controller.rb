class PagesController < ApplicationController
    
    def index
        @pages = Page.all
    end
    def show
        @page = Page.find(params[:id])
        #render html: params[:id]
        #render plain: @page.title
    end

    

    def new
        @page = Page.new
        
    end

    def create
        #render plain: params.to_json
        @page = Page.new(page_params)
        @page.save
        redirect_to @page
    end
    def update

  @page = Page.find(params[:id])
        respond_to do |format|
          if @page.update(page_params)
            format.html { redirect_to @page, notice: 'Paget was successfully updated.' }
            format.json { render :show, status: :ok, location: @page }
          else
            format.html { render :edit }
            format.json { render json: @page.errors, status: :unprocessable_entity }
          end
        end


     
        
      end
      def destroy
        @page = Page.find(params[:id])
        @page.destroy
        respond_to do |format|
          format.html { redirect_to pages_path, notice: 'Post was successfully destroyed.' }
          format.json { head :no_content }
        end
      end



    def edit
        @page = Page.find(params[:id])
        
    end

    def page_params
        params.require(:page).permit(:title, :body, :slug)
      end


end
